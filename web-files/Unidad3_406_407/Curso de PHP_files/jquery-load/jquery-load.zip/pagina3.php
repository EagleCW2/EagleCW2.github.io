<?php
// Simulamos el tiempo que puede tardar la pagina en cargarse
sleep(2);
?>
P&aacute;gina3.
<p>La pagina inicial de la documentacion de la instrucci&oacute;n load de jquery se encuentra en la url: <a href='http://api.jquery.com/load/' target='_blank' class='enlace'>http://api.jquery.com/load/</a></p>
